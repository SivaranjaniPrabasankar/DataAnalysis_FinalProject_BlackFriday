# Sivaranjani - A20436206
getwd()
setwd('D:/Spring-19/ITMD_527_DATA Analytics/Project/black-friday/')

# Loading File and Finding Missing values
Blackfriday_Data=read.table('BlackFriday.csv',header=T,sep=',')

# Replacing missing values
Blackfriday_Data$Product_Category_2=ifelse(is.na(Blackfriday_Data$Product_Category_2),0,Blackfriday_Data$Product_Category_2)
is.na(Blackfriday_Data$Product_Category_2)

Blackfriday_Data$Product_Category_3=ifelse(is.na(Blackfriday_Data$Product_Category_3),0,Blackfriday_Data$Product_Category_3)
is.na(Blackfriday_Data$Product_Category_3)

# Shuffling of data
# Blackfriday_Data[sample(nrow(Blackfriday_Data)),]
Selectdata=sample(1:nrow(Blackfriday_Data),0.8*nrow(Blackfriday_Data))
# total ; 537577, train : 430061, test 107516 
BF_traindata=Blackfriday_Data[Selectdata,] # 80% of 537577 row
BF_testdata=Blackfriday_Data[-Selectdata,]  

# Assigning variables 

User_ID=BF_traindata$User_ID
Product_ID=BF_traindata$Product_ID
Gender=BF_traindata$Gender
Marital_Status=BF_traindata$Marital_Status
Occupation=BF_traindata$Occupation
City_Category=BF_traindata$City_Category
Stay_In_Current_City_Years=BF_traindata$Stay_In_Current_City_Years
Product_Category_1=BF_traindata$Product_Category_1
Product_Category_2=BF_traindata$Product_Category_2
Product_Category_3=BF_traindata$Product_Category_3
Purchase=BF_traindata$Purchase
Age=BF_traindata$Age

# Logistic Regression

Full_Logistic_Model=glm(Marital_Status~Gender+Occupation+City_Category+Stay_In_Current_City_Years+Product_Category_1+Product_Category_2+Product_Category_3+Purchase+Age,data=BF_traindata,family=binomial())
summary(Full_Logistic_Model)

# Base Model
Base_Logistic_Model=glm(Marital_Status~Age,data=BF_traindata,family=binomial())
summary(Base_Logistic_Model)

#  Logistic Model - after Forward  Model  
Forward_Logistic_Model=step(Base_Logistic_Model,scope=list(upper=Full_Logistic_Model,lower=~1),direction ="forward", trace=F)
summary(Forward_Logistic_Model)

#  Logistic Model - after Backward  Model  
Back_Logistic_Model=step(Full_Logistic_Model,direction ="backward", trace=F)
summary(Back_Logistic_Model)

#  Logistic Model - after Stepwise  Model  
Stepwise_Logistic_Model=step(Base_Logistic_Model,scope=list(upper=Full_Logistic_Model,lower=~1),direction ="both", trace=F)
summary(Stepwise_Logistic_Model)

install.packages("Metrics")
library(Metrics)

# Finding accuracy for Full Model
Predicted_Full=predict(Full_Logistic_Model,type="response", newdata=BF_testdata)
for(i in 1:length(Predicted_Full)){
  if(Predicted_Full[i]>0.5){
    Predicted_Full[i]=1
  }else{
    Predicted_Full[i]=0
  }
}
accuracy(BF_testdata$Marital_Status,Predicted_Full)


# Finding accuracy for Forward Model

Predicted_Forward=predict(Forward_Logistic_Model,type="response", newdata=BF_testdata)
for(i in 1:length(Predicted_Forward)){
  if(Predicted_Forward[i]>0.5){
    Predicted_Forward[i]=1
  }else{
    Predicted_Forward[i]=0
  }
}
accuracy(BF_testdata$Marital_Status,Predicted_Forward)

# Finding accuracy for Backward Model
Predicted_Back=predict(Back_Logistic_Model,type="response", newdata=BF_testdata)
for(i in 1:length(Predicted_Back)){
  if(Predicted_Back[i]>0.5){
    Predicted_Back[i]=1
  }else{
    Predicted_Back[i]=0
  }
}
accuracy(BF_testdata$Marital_Status,Predicted_Back)


# Finding accuracy for Stepwise Model
Predicted_Step=predict(Stepwise_Logistic_Model,type="response", newdata=BF_testdata)
for(i in 1:length(Predicted_Step)){
  if(Predicted_Step[i]>0.5){
    Predicted_Step[i]=1
  }else{
    Predicted_Step[i]=0
  }
}
accuracy(BF_testdata$Marital_Status,Predicted_Step)


# Sivaranjani - A20436206
getwd()
setwd('D:/Spring-19/ITMD_527_DATA Analytics/Project/black-friday/')

# Loading File and Finding Missing values
Blackfriday_Data=read.table('BlackFriday.csv',header=T,sep=',')

# Replacing missing values
Blackfriday_Data$Product_Category_2=ifelse(is.na(Blackfriday_Data$Product_Category_2),0,Blackfriday_Data$Product_Category_2)
is.na(Blackfriday_Data$Product_Category_2)

Blackfriday_Data$Product_Category_3=ifelse(is.na(Blackfriday_Data$Product_Category_3),0,Blackfriday_Data$Product_Category_3)
is.na(Blackfriday_Data$Product_Category_3)

install.packages("plyr")
library(plyr)

Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("0-17"="Teenager"))
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("18-25"="YoungAdult"))
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("26-35"="Adult"))
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("36-45"="SenoirAdult"))
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("46-50"="MiddleAged"))
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("51-55"="Early fifties"))
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("55+"="SeniorCitizen"))
BF_Age=Blackfriday_Data$Age

Blackfriday_Data$Marital_Status=as.factor(Blackfriday_Data$Marital_Status)
Blackfriday_Data$Marital_Status=revalue(Blackfriday_Data$Marital_Status,c("0"="Single"))
Blackfriday_Data$Marital_Status=revalue(Blackfriday_Data$Marital_Status,c("1"="Married"))

Blackfriday_Data$Purchase=as.factor(Blackfriday_Data$Purchase)
Blackfriday_Data$Occupation=as.factor(Blackfriday_Data$Occupation)
Blackfriday_Data$Product_Category_1=as.factor(Blackfriday_Data$Product_Category_1)
Blackfriday_Data$Product_Category_2=as.factor(Blackfriday_Data$Product_Category_2)
Blackfriday_Data$Product_Category_3=as.factor(Blackfriday_Data$Product_Category_3)

str(Blackfriday_Data)

# Shuffling of data
# Blackfriday_Data[sample(nrow(Blackfriday_Data)),]
Selectdata=sample(1:nrow(Blackfriday_Data),size=round(0.2*nrow(Blackfriday_Data)))
# total ; 537577, train : 430061, test 107516 
traindata=Blackfriday_Data[-Selectdata,] # 80% of 537577 row
testdata=Blackfriday_Data[Selectdata,]  
testdef=Blackfriday_Data$Age[-Selectdata]

traindata=traindata[,-1]
traindata=traindata[,-1]
testdata=testdata[,-1]
testdata=testdata[,-1]
testdata=testdata[,-2]# removing age

# Assigning variables
Gender=traindata$Gender
Marital_Status=traindata$Marital_Status
Occupation=traindata$Occupation
City_Category=traindata$City_Category
Product_Category_1=traindata$Product_Category_1
Product_Category_2=traindata$Product_Category_2
Product_Category_3=traindata$Product_Category_3
Stay_In_Current_City_Years=traindata$Stay_In_Current_City_Years
Purchase=traindata$Purchase
Age=traindata$Age


install.packages("naivebayes")
library(naivebayes)
library(Metrics)
  
NB_Model1=naive_bayes(Age~Gender+Occupation+City_Category+Stay_In_Current_City_Years+Marital_Status+Product_Category_1+Product_Category_2+Product_Category_3+Purchase,traindata)
testdataM1=testdata
testdataM1=testdataM1[,-3]
pred=predict(NB_Model1,testdataM1)
accuracy(testdef,pred) # 0.3420972

NB_Model2=naive_bayes(Age~.,traindata)
pred2=predict(NB_Model2,testdata)
accuracy(testdef,pred2) #  0.3109482

NB_Model3=naive_bayes(Age~Gender+Marital_Status,traindata)
testdataM3=testdata
str(testdataM3)
testdataM3=testdataM3[,-2]
testdataM3=testdataM3[,-3]
pred3=predict(NB_Model3,testdataM3)
accuracy(testdef,pred3) # 0.3992238

NB_Model4=naive_bayes(Age~Marital_Status,traindata)
testdataM4=testdata
str(testdataM4)
testdataM4=testdata[,5]
testdataM4=testdataM4[,-3]
pred4=predict(NB_Model4,testdataM4)
accuracy(testdef,pred4) # 0.3992238

NB_Model5=naive_bayes(Age~Gender+Occupation+Marital_Status,traindata)
testdataM5=testdata
str(testdataM5)
testdataM5=testdataM5[,-3]
testdataM5=testdataM5[,-4]
pred5=predict(NB_Model5,testdataM5)
accuracy(testdef,pred5) # 0.343218

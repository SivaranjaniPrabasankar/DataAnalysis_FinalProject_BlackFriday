# Sivaranjani - A20436206
getwd()
setwd('D:/Spring-19/ITMD_527_DATA Analytics/Project/black-friday/')

# Loading File and Finding Missing values
BF_Data=read.table('BlackFriday.csv',header=T,sep=',')


BF_Data=BF_Data[,-1]
BF_Data=BF_Data[,-1]


BF_Data$Product_Category_2=ifelse(is.na(BF_Data$Product_Category_2),0,BF_Data$Product_Category_2)
is.na(BF_Data$Product_Category_2)

BF_Data$Product_Category_3=ifelse(is.na(BF_Data$Product_Category_3),0,BF_Data$Product_Category_3)
is.na(BF_Data$Product_Category_3)

#CONVERTING label to nominal
BF_Data$City_Category=factor(BF_Data$City_Category)

num_vars=sapply(BF_Data, is.numeric)
num_vars

install.packages("dummies")
library(dummies)
BF_Dummy_Data=dummy.data.frame(BF_Data,names=c("Gender","Age","Stay_In_Current_City_Years"))
BF_Dummy_Data

head(BF_Dummy_Data)
BF_Dummy_Data[num_vars]=lapply(BF_Dummy_Data[num_vars],scale)

#myvars=c("Gender","Marital_Status","Occupation","Stay_In_Current_City_Years","Product_Category_1","Product_Category_2","Product_Category_3","Purchase","Age")
myvars=c(City_Category)
subset_data=BF_Dummy_Data[-11]
head(subset_data)

set.seed(537577)
test=1:376304
trainset=subset_data[-test,]
testset=subset_data[test,]

traindef=BF_Dummy_Data$City_Category[-test]
testdef=BF_Dummy_Data$City_Category[test]


library(class)

knn_model1=knn(trainset,testset,traindef,k=1)
summary(knn_model1)
knn_model1


knn_model2=knn(trainset,testset,traindef,k=3)
summary(knn_model2)


knn_model3=knn(trainset,testset,traindef,k=5)
summary(knn_model3)
library(Metrics)

knn_model101=knn(trainset,testset,traindef,k=101)
summary(knn_model101)

knn_model299=knn(trainset,testset,traindef,k=1001)
summary(knn_model299)

knn_model399=knn(trainset,testset,traindef,k=1001)
summary(knn_model399)

knn_model499=knn(trainset,testset,traindef,k=499,prob = FALSE,use.all = F)
summary(knn_model499)

knn_model1001=knn(trainset,testset,traindef,k=1001)
summary(knn_model1001)


accuracy(testdef,knn_model1)
accuracy(testdef,knn_model2)
accuracy(testdef,knn_model3)

accuracy(testdef,knn_model101)
accuracy(testdef,knn_model299)
accuracy(testdef,knn_model399)
accuracy(testdef,knn_model499)

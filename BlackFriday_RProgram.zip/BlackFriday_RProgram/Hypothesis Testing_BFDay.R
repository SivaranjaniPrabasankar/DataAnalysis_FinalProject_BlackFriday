# Sivaranjani - A20436206
getwd()
setwd('D:/Spring-19/ITMD_527_DATA Analytics/Project/black-friday/')

# Loading File and Finding Missing values
Blackfriday_Data=read.table('BlackFriday.csv',header=T,sep=',')

# 1) Hypothesis Testing

install.packages("dplyr")
library(dplyr)

# 1.1) Checking for missing values
is.na(Blackfriday_Data$Gender)
is.na(Blackfriday_Data$Stay_In_Current_City_Years)
is.na(Blackfriday_Data$Product_Category_1)
is.na(Blackfriday_Data$Product_Category_2)

# 1.1) Assigning variables
Gender=(as.numeric(Blackfriday_Data$Gender))
Stay=as.numeric(Blackfriday_Data$Stay_In_Current_City_Years)
Prod1=Blackfriday_Data$Product_Category_1
Prod2=na.omit(Blackfriday_Data$Product_Category_2)
is.na(Prod2)
Prod3=na.omit(Blackfriday_Data$Product_Category_3)
is.na(Prod3)
Age=Blackfriday_Data$Age
City_Category=Blackfriday_Data$City_Category
Purchase=Blackfriday_Data$Purchase

install.packages("BSDA")
library(BSDA)
plot(Blackfriday_Data$Stay_In_Current_City_Years)

# 1.3) Z test

# ONE SAMPLED HYPOTHESIS TESTING
# Average stay in current city is equal to 3 ?
z.test(Stay,alternative="greater",mu=2.86,sigma.x=sd(Stay),conf.level=0.95)

# TWO SAMPLED HYPOTHESIS TESTING
# Average quantity of purchase on Product category 1 and Product Category 2 are equal
z.test(Prod1,Prod2,alternative="two.sided",mu=0,sigma.x=sd(Prod1),sigma.y=sd(Prod2),paired = FALSE,conf.level=0.95)

# Average quantity of purchase on Product category 2 and Product Category 3 are equal
z.test(Prod2,Prod3,alternative="two.sided",mu=0,sigma.x=sd(Prod2),sigma.y=sd(Prod3),conf.level=0.95)

# Average quantity of purchase on Product category 1 and Product Category 3 are equal
z.test(Prod1,Prod3,alternative="two.sided",mu=0,sigma.x=sd(Prod1),sigma.y=sd(Prod3),conf.level=0.95)

# Purchase of male and female are equal
# Average purchase by Male and Female are equal ?
MaleP=0;FemaleP=0;k=1;j=1;
Purchase=Blackfriday_Data$Purchase

for(i in 1:length(Gender)){
  if(Gender[i]==1){
    MaleP[j]=Purchase[i]
    j=j+1
  }else{
    FemaleP[k]=Purchase[i]
    k=k+1
  }
}
z.test(MaleP,FemaleP,alternative="two.sided",mu=0,sigma.x=sd(MaleP),sigma.y=sd(FemaleP),conf.level=0.95)

install.packages("psych")
library(psych)
describe(Blackfriday_Data)
# ANOVA

# Average of purchases are equal across all City category
plot(Purchase~City_Category)
BF_AnovaModel_City=lm(Purchase~City_Category)
summary(BF_AnovaModel_City)

# Average of purchases are equal across all age category
plot(Purchase~Age)
BF_AnovaModel_Age=lm(Purchase~Age)
summary(BF_AnovaModel_Age)


# Residual Analysis for ANOVA
Residual1 = rstandard(BF_AnovaModel_City)
#step1 : Standardized residual vs predicted values
plot(fitted(BF_AnovaModel_City), Residual1, main="Residuals vs Predicted plot ( BF_AnovaModel_City)") 
abline(a=0, b=0, col='red')
shapiro.test(Residual1)
ks.test(Residual1,"pnorm")

Residual2 = rstandard(BF_AnovaModel_Age)
#step1 : Standardized residual vs predicted values
plot(fitted(BF_AnovaModel_Age), Residual2, main="Residuals vs Predicted plot ( BF_AnovaModel_Age)") 
abline(a=0, b=0, col='red')
shapiro.test(Residual2)
ks.test(Residual2,"pnorm")


qqnorm(Residual1)
qqline(Residual1,col=2)

qqnorm(Residual2)
qqline(Residual2,col=2)

#get working directory
getwd();

#setup working path
setwd('D:/Spring-19/ITMD_527_DATA Analytics/Project/black-friday/')

# Loading File and Finding Missing values
Blackfriday_Data=read.table('BlackFriday.csv',header=T,sep=',')

# Replacing missing values
Blackfriday_Data$Product_Category_2=ifelse(is.na(Blackfriday_Data$Product_Category_2),0,Blackfriday_Data$Product_Category_2)
is.na(Blackfriday_Data$Product_Category_2)

Blackfriday_Data$Product_Category_3=ifelse(is.na(Blackfriday_Data$Product_Category_3),0,Blackfriday_Data$Product_Category_3)
is.na(Blackfriday_Data$Product_Category_3)

BF_User=Blackfriday_Data$User_ID
BF_Prod=Blackfriday_Data$Product_ID

BF_Gender=Blackfriday_Data$Gender
BF_Marital=Blackfriday_Data$Marital_Status

BF_Occupation=Blackfriday_Data$Occupation

BF_City=Blackfriday_Data$City_Category

BF_Prod1=Blackfriday_Data$Product_Category_1
BF_Prod2=Blackfriday_Data$Product_Category_2
BF_Prod3=Blackfriday_Data$Product_Category_3
BF_Purchase=Blackfriday_Data$Purchase

install.packages("plyr")
library(plyr) 

# Data pre-processing Age
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("0-17"="Teenager"))
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("18-25"="YoungAdult"))
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("26-35"="Adult"))
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("36-45"="SenoirAdult"))
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("46-50"="MiddleAged"))
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("51-55"="Early fifties"))
Blackfriday_Data$Age=revalue(Blackfriday_Data$Age,c("55+"="SeniorCitizen"))
BF_Age=Blackfriday_Data$Age

# Data pre-processing stay
Blackfriday_Data$Stay_In_Current_City_Years= as.integer(as.factor(Blackfriday_Data$Stay_In_Current_City_Years))
BF_Stay=Blackfriday_Data$Stay_In_Current_City_Years

# Correlation table
cor(cbind(BF_Purchase,BF_User,BF_Prod,BF_Gender,BF_Age,BF_Occupation,BF_City,BF_Stay,BF_Marital,BF_Prod1,BF_Prod2,BF_Prod3))

# plot(Blackfriday_Data$Purchase,Blackfriday_Data$Product_ID)
# Shuffling of data
# Blackfriday_Data[sample(nrow(Blackfriday_Data)),]
# Selectdata=sample(1:nrow(Auto_Data),0.8*nrow(Auto_Data))

# total ; 537577, train : 430061, test 107516 
traindata=Blackfriday_Data[1:430061,] # 80% of 537577 row
testdata=Blackfriday_Data[430062:537577,]  


# Assigning variables
User_ID=traindata$User_ID
Product_ID=traindata$Product_ID
Gender=as.factor(traindata$Gender) # Creating Dummy for Gender
Age=traindata$Age
Occupation=sqrt(traindata$Occupation)
City_Category=as.factor(traindata$City_Category)  # Creating Dummy for Category
Stay_In_Current_City_Years=sqrt(traindata$Stay_In_Current_City_Years)
Marital_Status=as.factor(traindata$Marital_Status)
Product_Category_1=sqrt(traindata$Product_Category_1)
Product_Category_2=sqrt(traindata$Product_Category_2)
Product_Category_3=sqrt(traindata$Product_Category_3)
Purchase=traindata$Purchase


# Model 1: Building model with all variables 


Full_Model=lm(formula=traindata$Purchase~traindata$Gender+traindata$Age+traindata$Occupation+traindata$City_Category+traindata$Stay_In_Current_City_Years+traindata$Marital_Status+traindata$Product_Category_1+traindata$Product_Category_2+traindata$Product_Category_3,data = traindata)
summary(Full_Model)

Full_Model_XTrans=lm(formula=Purchase~Gender+Age+Occupation+City_Category+Stay_In_Current_City_Years+Marital_Status+Product_Category_1+Product_Category_2+Product_Category_3,data = traindata)
summary(Full_Model_XTrans)

# Feature selection

# Manual
Full_Model_XTrans1=lm(formula=Purchase~Gender+Age+Occupation+City_Category+Marital_Status+Product_Category_1+Product_Category_2+Product_Category_3,data = traindata)
summary(Full_Model_XTrans1)

# Step

Back_Model=step(Full_Model_XTrans,direction ="backward", trace=F)
summary(Back_Model)

# base model for Forward and stepwise
Base_Model=lm(formula=Purchase~Product_Category_1,data = traindata)
summary(Base_Model)

#  Linear Model - after Forward  Model  
Fwd_Model=step(Base_Model,scope=list(upper=Full_Model_XTrans,lower=~1),direction ="forward", trace=F)
summary(Fwd_Model)

#  Linear Model - after stepwise  Model  
step_Model=step(Base_Model,scope=list(upper=Full_Model_XTrans,lower=~1),direction ="both", trace=F)
summary(step_Model)

Residual = rstandard(Full_Model_XTrans)

#step1 : Standardized residual vs predicted values
plot(fitted(Back_Model), Residual, main="Residuals vs Predicted plot") 
abline(a=0, b=0, col='red')

# Y Transformation

Full_Model_YTrans=lm(formula=sqrt(traindata$Purchase)~traindata$Gender+traindata$Age+traindata$Occupation+traindata$City_Category+traindata$Stay_In_Current_City_Years+traindata$Marital_Status+traindata$Product_Category_1+traindata$Product_Category_2+traindata$Product_Category_3,data = traindata)
summary(Full_Model_YTrans)

Full_Model_XYTrans=lm(formula=sqrt(Purchase)~Gender+Age+Occupation+City_Category+Stay_In_Current_City_Years+Marital_Status+Product_Category_1+Product_Category_2+Product_Category_3,data = traindata)
summary(Full_Model_XYTrans)

Back_YModel=step(Full_Model_YTrans,direction ="backward", trace=F)
summary(Back_YModel)

# base model for Forward and stepwise

Base_YModel=lm(formula=sqrt(Purchase)~traindata$Product_Category_1,data = traindata)
summary(Base_YModel)

Base_YModel=lm(formula=log(Purchase)~Product_Category_1,data = traindata)
summary(Base_Model)

Fwd_YModel=step(Base_YModel,scope=list(upper=Full_Model_YTrans,lower=~1),direction ="forward", trace=F)
summary(Fwd_YModel)

Step_YModel=step(Base_YModel,scope=list(upper=Full_Model_YTrans,lower=~1),direction ="both", trace=F)
summary(Step_YModel)

Step_YModel=step(Base_Model,scope=list(upper=Full_Model_YTrans,lower=~1),direction ="both", trace=F)
summary(Step_YModel)

# Residual analysis

Residual_YTran = rstandard(Full_Model_YTrans)

#step1 : Standardized residual vs Predicted
plot(fitted(Back_YModel), Residual_YTran, main="Residuals vs Predicted plot") 
abline(a=0, b=0, col='red')

#step2 : Standardized residual vs X values
plot(Gender, Residual_YTran, main="Residuals vs Gender") 
abline(a=0, b=0, col='red')

plot(Age, Residual_YTran, main="Residuals vs Age") 
abline(a=0, b=0, col='red')

plot(Occupation, Residual_YTran, main="Residuals vs Occupation") 
abline(a=0, b=0, col='red')

plot(Stay_In_Current_City_Years, Residual_YTran, main="Residuals vs Stay_In_Current_City_Years") 
abline(a=0, b=0, col='red')

plot(Product_Category_1, Residual_YTran, main="Residuals vs Product_Category_1") 
abline(a=0, b=0, col='red')

plot(Product_Category_2, Residual_YTran, main="Residuals vs Product_Category_2") 
abline(a=0, b=0, col='red')

plot(Product_Category_3, Residual_YTran, main="Residuals vs Product_Category_3") 
abline(a=0, b=0, col='red')


shapiro.test(Residual_YTran)

qqnorm(Residual_YTran)
qqline(Residual_YTran,col=2)

install.packages("car",dependencies = TRUE)
library(car)

vif(Residual_YTran)


# Finding Root mean square
obs1=testdata[,"Purchase"]

# for model y transformed
#P_Test=predict.glm(Full_Model_YTrans,testdata)
P_Test=(predict.glm(Full_Model_YTrans,testdata)*(predict.glm(Full_Model_YTrans,testdata)))
RMSE_Test=sqrt((obs1-P_Test)%*%(obs1-P_Test)/nrow(testdata))
RMSE_Test

obs2=traindata[,"Purchase"]

P_Train=exp(predict.glm(Full_Model_YTrans,traindata) )
RMSE_Train=sqrt((obs2-P_Train)%*%(obs2-P_Train)/nrow(traindata))
RMSE_Train

ks.test(traindata,traindata$Purchase)

d=ks.test(Full_Model_res, "pnorm") # D = 0.296, p-value = 0.005563
summary(d)
KS_YTran=ks.test(Residual_YTran, "pt",df=nrow(mtcars)-2-2) 


#Influentional Points

install.packages()
library()

#To compute predicted value and standard error

predict(Full_Model_YTrans, new, se.fit= TRUE)

#To compute predicted value and prediction interval

predict(Full_Model_YTrans, new, interval="prediction", level=0.95)

im=influence.measures(Full_Model_YTrans)
print(im)

#To find the cooks distance - 
cooks.distance(Full_Model_YTrans)


#Multicollinearity Problems

vif(Full_Model_YTrans)
sqrt(vif(Full_Model_YTrans))